﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace EditingText
{
    public partial class Form1 : Form
    {

        string filePath = string.Empty; //расположение файла
        public Form1()
        {
            InitializeComponent();
        }

        private void butOpenF_Click(object sender, EventArgs e)
        {
            var fileContent = string.Empty;
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.InitialDirectory = "c:\\";
                openFileDialog.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*";
                openFileDialog.FilterIndex = 2;
                openFileDialog.RestoreDirectory = true;

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    //Get the path of specified file
                    filePath = openFileDialog.FileName;

                    //Read the contents of the file into a stream
                    var fileStream = openFileDialog.OpenFile();

                    using (StreamReader reader = new StreamReader(fileStream))
                    {
                        fileContent = reader.ReadToEnd();
                        fileContent = fileContent.Replace("\r\n\r\n", "\r\n");
                        fileContent = fileContent.Replace("  ", " ");
                        tBFile.Text = fileContent.Replace("\r\n\r\n", "\r\n");
                    }
                }
            }

        }

        private void butDelSymbol_Click(object sender, EventArgs e)
        {
            var text = string.Empty;
            text = tBFile.Text;
            if (text != " ")
            {
                tBFile.Text = text.Replace(tBDelSymbol.Text, "");
            }
            else
            { MessageBox.Show("Пробелы удалять нельзя!"); }
        }

        private void butDelWord_Click(object sender, EventArgs e)
        {
            try
            {
                var text = tBFile.Text;
                int length = Convert.ToInt32(tBDelWord.Text);
                int lengthR = 1;
                while (length >= lengthR)
                {
                    if (!string.IsNullOrEmpty(text) && lengthR > 0)
                    {
                        text = Regex.Replace(text, "\\b[\\w]{" + lengthR + "}\\b", string.Empty, RegexOptions.Compiled);
                        lengthR++;
                    }
                }
                tBFile.Text = text;
            }
            catch
            {
                MessageBox.Show("Неверные параметры!");
            }
        }

        private void butFileSave_Click(object sender, EventArgs e)
        {
            if (cBRewrite.Checked)
            {
                WriteAsync(tBFile.Text, filePath);
            }
            else
            {

                if (tBNewNFile.Text != null)
                {
                    string path = string.Empty;
                    using (var path_dialog = new FolderBrowserDialog())
                        if (path_dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                        {
                            path = path_dialog.SelectedPath;
                            FileInfo targetDir = new FileInfo(path);
                            label3.Text = targetDir.FullName+ "\\" + tBNewNFile.Text + ".txt";
                        }
                    WriteFile(path);
                }
                else
                { MessageBox.Show("Не введено название!"); }
            }
        }

        static async Task WriteAsync(string text, string filePath)
        {
            //string text = tBFile.Text;
            try
            {
                using (StreamWriter sw = new StreamWriter(filePath, false, System.Text.Encoding.Default))
                {
                    await sw.WriteLineAsync(text);
                }
                MessageBox.Show("Запись выполнена");
            }
            catch
            {
                MessageBox.Show("Ошибка записи");
            }
        }

        private void WriteFile(string path)
        {
            string text = tBFile.Text;
            try
            {
                    path += "\\" + tBNewNFile.Text + ".txt";
                    using (StreamWriter sw = new StreamWriter(path, false, System.Text.Encoding.Default))
                    {
                        sw.WriteLine(text);
                    }
                    MessageBox.Show("Запись выполнена");
            }
            catch
            {
                    MessageBox.Show("Ошибка записи");
            }   
        }

        private void cBRewrite_CheckedChanged(object sender, EventArgs e)
        {
            if (cBRewrite.Checked == true)
            { tBNewNFile.Enabled = false; }
            else
            { tBNewNFile.Enabled = true; }
        }
    }
    }

